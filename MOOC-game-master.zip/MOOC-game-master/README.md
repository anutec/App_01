# Juego demostracion de las capacidades del acelerometro

## Usage

### Desktop

In your browser, open the file:

    /www/index.html

